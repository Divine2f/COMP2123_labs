var express = require('express')
var bodyParser = require('body-parser')

const app = new express()
app.use(bodyParser.json())
app.use(express.json())

const SERVER_PORT = 8085;

app.get('/hello', function(req, res){
    res.send("Hello express JS")  // send a response to the client
})


app.get('/user', function(req, res) {
    const firstname = req.query.firstname
    const lastname = req.query.firstname

    const data = {"firstname": firstname, "lastname": lastname}

    res.send(JSON.stringify(data))
})

app.post('/user/:firstname/:lastname', function(req, res) {
    const {firstname, lastname} = req.params
    const data = {"firstname": firstname, "lastname": lastname}

    res.send(JSON.stringify(data))
})

app.listen(SERVER_PORT, function() {
    console.log(`Server is listening on port ${SERVER_PORT}`);
})